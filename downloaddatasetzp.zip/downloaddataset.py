from roboflow import Roboflow

rf = Roboflow(api_key="pkaGKnAKKwzKuVJ04B17")
project = rf.workspace("-jwzpw").project("continuous_fire")
version = project.version(6)
dataset = version.download("yolov11")
                

# # Load the trained YOLOv5 model
# model = torch.hub.load('ultralytics/yolov5', 'custom', path=dataset.location + "/best.pt")  # Adjust path as needed

# # Start the webcam feed
# cap = cv2.VideoCapture(0)  # 0 is the default webcam on most systems
