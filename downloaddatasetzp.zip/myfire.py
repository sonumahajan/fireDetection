import cv2
import torch

# Load the trained YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'custom', path='/path/to/best.pt')  # Adjust with path to best.pt

# Start webcam feed
cap = cv2.VideoCapture(0)  # 0 is the default webcam on most systems

while True:
    ret, frame = cap.read()  # Capture frame by frame
    if not ret:
        break

    # Perform inference on the frame
    results = model(frame)

    # Render results (bounding boxes, labels, etc.)
    results.render()  # This will add bounding boxes to the frame

    # Display the resulting frame with predictions
    cv2.imshow("Fire Detection", results.imgs[0])

    # Press 'q' to exit the video loop
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release webcam and close windows
cap.release()
cv2.destroyAllWindows()
